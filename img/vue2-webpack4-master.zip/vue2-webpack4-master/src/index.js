import Vue from 'vue'
import App from './components/app/app.vue';

new Vue({
    el: '#root',
    render: h => h(App)
});