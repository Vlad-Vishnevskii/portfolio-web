# vue2-webpack4

npm i

npm run build
